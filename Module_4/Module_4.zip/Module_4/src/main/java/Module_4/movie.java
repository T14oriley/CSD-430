package Module_4;

public class movie {
	String title;
	String director;
	int year;
	String isSeries;
	
	movie(String title, String director, int year, String isSeries){
		this.title = title;
		this.director = director;
		this.year = year;
	}
}